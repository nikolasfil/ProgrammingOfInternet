# Task list

Παράδειγμα μιας απλής εφαρμογής express.js.

Πρώτα κατεβάστε τα πακέτα node με `npm install`.

Τρέξτε έπειτα `npm audit fix --force`

Τρέχει με `npm run watch` (δείτε την εγγραφή στο "scripts" του pacakge.json).
