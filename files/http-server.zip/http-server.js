// CommonJS module system:
const http = require('http')
const dotenv = require('dotenv')
dotenv.config()

// ES6 module system: (για να λειτουργήσει πρέπει να έχουμε στο package.json το "type": "module", ή κατάληξη .mjs
//import http from 'http'

const port = process.env.PORT || 23000

const server = http.createServer((req, res) => {
    console.log(req)
    res.statusCode = 200
    res.setHeader('Content-Type', 'text/html')

    res.end('<html><head><meta charset="utf-8"</head><body>Hello World - Γειά σου κόσμε</body></html>\n')
})

server.listen(port, () => {
    console.log(`Server listening on port http://127.0.0.1:${port}`)
})