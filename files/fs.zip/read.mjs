import * as fs from 'fs';

// Για να πάρουμε την πλήρη διαδρομή του αρχείου:
// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/import.meta
import { fileURLToPath } from 'node:url';
const filePath = fileURLToPath(new URL('shopping-list.txt', import.meta.url));
//---

fs.readFile(filePath, { encoding: 'utf8' }, (err, data) => {
   if (err) {
      console.error(err);
      return;
   }
   console.log('με συνάρτηση επιστροφής: ' + data); // τα περιεχόμενα του αρχείου
});

// με υποσχέσεις (promises)
// καταρχή  κάνουμε import τη σχετική βιβλιοθήκη (που τώρα ονομάζουμε fsp για να μην έχει σύγκρουση με το fs που κάναμε import πιο πάνω)
import * as fsp from 'fs/promises';

// async/await
try {
   const data = await fsp.readFile(filePath, { encoding: 'utf8' });
   console.log('με async/await: ' + data);
} catch (error) {
   console.error(error);
}

// με απλές υποσχέσεις
fsp.readFile(filePath, { encoding: 'utf8' })
   .then((data) => {
      console.log('Με promises: ' + data);
   })
   .catch((err) => {
      console.error(err);
   });
