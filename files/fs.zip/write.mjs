import * as fs from 'fs';

// Για να πάρουμε την πλήρη διαδρομή του αρχείου:
// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/import.meta
import { fileURLToPath } from 'node:url';
const filePath = fileURLToPath(new URL('shopping-list2.txt', import.meta.url));
//---


fs.open(filePath, 'a+', (err, fd) => {
    fs.write(fd, "test2", (err, written, string) => {
        if (err)
            console.log(err, written, string)
        else
            console.log(string)
    })
})


fs.stat(filePath, (err, stat) => {
    if (err) {
        console.log(err)
        return
    }
    console.log(stat.isFile())
    console.log(stat.size)
})

import * as path from 'node:path'

console.log(path.extname(filePath))

// fs.writeFile(filePath, contnent, { encoding: 'utf8', flag: "a" }, (err) => {
//     // If an error occurred, show it and return
//     if (err) return console.error(err);
//     // Successfully wrote to the file!
// });


// const fs = require('fs').promises;

// This must run inside a function marked `async`:
// const file = await fs.readFile(filePath, 'utf8');


// promise-based
// new Promise((resolve, reject) => {
//     fs.writeFile(filePath, "a promise is a promise", (err) => {
//         if (err)
//             reject(err);
//         else
//             resolve("all ok");
//     });
// }).then((result) => {
//     console.log("result: " + result)
// }).catch((err) => {
//     console.log("error: " + err);
// });


// // --- async/await
// const fsPromise = require('fs').promises;

// (async () => {
//     await fsPromise.writeFile(filePath, ', as promised', { flag: 'a+' });
// })();


// Synchronous

// import fs from 'fs';

// try {
//     let fd = fs.openSync(filePath, 'a+')
//     fs.writeSync(fd, "Μπανάνες\n");
//     fs.closeSync(fd);
//     console.log("Τέλος")
// }
// catch (err) {
//     if (err.code == 'EACCES')
//         console.error("Δεν έχω πρόσβαση")
//     else
//         console.error("Παρουσιάστηκε σφάλμα: ", err.code)
// }



