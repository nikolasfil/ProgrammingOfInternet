// 1
import { Person, myName, default as myAge } from './mymodule.mjs' 
// 2
import whatsMyAge from './mymodule.mjs' // αυτόματο rename του default export σε whatsMyAge
// 3
import * as MyTest from './mymodule.mjs'
// Επίσης:
//import calculateAge, { Person, myName, default as myAge } from './mymodule.mjs' 
//import calculateAge, * as MyTest from './mymodule.mjs'

// Χρήση:
//1:
console.log(myName)
console.log(Person.name)
console.log(myAge(1953)) 

//2:
console.log(whatsMyAge(1943)) 

//3:
console.log(MyTest.myName)
