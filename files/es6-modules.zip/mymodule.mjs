//mymodule.mjs
export { Person }; // named export
export let myName = 'Μήτσος'; // named export

export {}; // mdn: does not export an empty object — it exports nothing (an empty name list).

class Person {
   static name = 'Μαρία';
}

function calculateAge(birthYear) {
   return new Date().getFullYear() - birthYear;
}

export default calculateAge